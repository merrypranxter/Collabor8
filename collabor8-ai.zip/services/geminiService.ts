import { GoogleGenAI, GenerateContentResponse, Type } from '@google/genai';
import { PersonaCard, ArenaSession, ConversationTurn, ModeConfig } from '../types';

// Use GoogleGenAI, not the deprecated GoogleGenerativeAI.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });
const model = 'gemini-2.5-flash';

const buildSystemPrompt = (
    persona: PersonaCard,
    session: ArenaSession,
    allPersonas: PersonaCard[],
    modeConfig: ModeConfig | undefined
): string => {
    const personaList = allPersonas.map(p => `- ${p.display_name}`).join('\n');

    return `
You are an AI actor playing the role of a specific persona in a multi-round debate.
Your goal is to embody this persona as faithfully as possible and contribute to the debate according to the session rules.

**SESSION TOPIC:** ${session.topic}
**SESSION INSTRUCTIONS:** ${session.instructions}
**DEBATE STYLE:** ${session.debate_style}
**YOUR PERSONA:** ${persona.display_name}

--- PERSONA DETAILS ---
**BIO:** ${persona.voice.bio}
**MANNERISMS & SPEECH PATTERNS:** ${persona.voice.mannerisms}
**LEXICON (Keywords to use):** ${persona.voice.lexicon.join(', ')}
**TONE:** ${persona.style.tone}
**GOALS IN THIS DEBATE:** ${persona.goals.join(', ')}
**CONSTRAINTS (What to avoid):**
- Avoid claims: ${persona.constraints.avoid_claims.join(', ')}
- Disallowed topics: ${persona.constraints.disallowed_topics.join(', ')}
--- END PERSONA DETAILS ---

**DEBATE PARTICIPANTS:**
${personaList}

**RULES:**
1.  **Stay in character.** Your response MUST be from the perspective of ${persona.display_name}. Do not break character. Do not refer to yourself as an AI.
2.  **Address the topic.** Your contribution must be relevant to the ongoing discussion and the overall topic.
3.  **Be concise but thorough.** Each turn should be a few paragraphs long unless the persona's style dictates otherwise.
4.  **Engage with others.** Refer to and build upon the points made by other participants in the conversation history.
5.  **Follow your goals.** Actively pursue your persona's goals within the context of the debate.
${modeConfig?.prefix_tag ? `\n**MODE:** This is a special mode. Your response will be prefixed with "${modeConfig.prefix_tag}". Embody the spirit of "${modeConfig.name}" mode.` : ''}

You will be given the conversation history so far. Your task is to generate the *next* response for your persona, ${persona.display_name}.
Your output should ONLY be the message content, without any preamble, title, or your persona's name.
`.trim();
};

const formatHistoryForGemini = (history: ConversationTurn[]): string => {
    if (history.length === 0) {
        return "The debate is just beginning. As your persona, please provide the opening statement.";
    }
    return history.map(turn => `**${turn.personaName}:**\n${turn.message}`).join('\n\n---\n\n');
}

export const generateDebateTurnStream = async function* (
    session: ArenaSession,
    persona: PersonaCard,
    allPersonas: PersonaCard[],
    conversation: ConversationTurn[],
    modeConfig: ModeConfig | undefined,
) {
    const systemInstruction = buildSystemPrompt(persona, session, allPersonas, modeConfig);
    const userPrompt = `
**CONVERSATION HISTORY SO FAR:**
---
${formatHistoryForGemini(conversation)}
---

**YOUR TURN:**
Now, as ${persona.display_name}, provide your response.
`.trim();

    try {
        const responseStream = await ai.models.generateContentStream({
            model,
            contents: userPrompt,
            config: {
                systemInstruction,
                temperature: modeConfig?.temperature ?? 0.7,
            },
        });

        for await (const chunk of responseStream) {
            yield chunk.text;
        }
    } catch (error) {
        console.error("Error generating debate turn:", error);
        throw new Error("Failed to get response from the AI. Please check your API key and network connection.");
    }
};

export const generatePersonaFromPrompt = async (prompt: string): Promise<Omit<PersonaCard, 'id'>> => {
    const generationPrompt = `
    Based on the user's request, create a detailed PersonaCard object in JSON format.
    The user wants a persona described as: "${prompt}".

    Flesh this out into a complete persona. Be creative and specific.
    - The display_name should be catchy and descriptive.
    - The bio should be a rich, third-person description.
    - Mannerisms should include specific example phrases.
    - Lexicon should be a list of relevant keywords.
    - Tone should be a few descriptive adjectives.
    - Goals should be a list of objectives for this persona in a debate.
    - Knowledge basis should be 'original', 'fictional', or 'public_figure_emulation'.
    - Fill out constraints, and tool_prefs reasonably. temperature_bias should be between -0.5 and 0.5.

    Your output MUST be a single, valid JSON object that conforms to the Omit<PersonaCard, 'id'> type structure provided below.
    Do not include any other text, explanations, or markdown formatting like \`\`\`json.
    `;
    
    const responseSchema = {
        type: Type.OBJECT,
        properties: {
            display_name: { type: Type.STRING },
            voice: {
                type: Type.OBJECT,
                properties: {
                    bio: { type: Type.STRING },
                    mannerisms: { type: Type.STRING },
                    lexicon: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: ['bio', 'mannerisms', 'lexicon'],
            },
            knowledge_mode: {
                type: Type.OBJECT,
                properties: {
                    basis: { type: Type.STRING, enum: ['original', 'fictional', 'public_figure_emulation'] },
                    sources_allowed: { type: Type.ARRAY, items: { type: Type.STRING } },
                    citation_style: { type: Type.STRING, enum: ['none', 'inline', 'footnote'] },
                },
                required: ['basis', 'sources_allowed', 'citation_style'],
            },
            constraints: {
                type: Type.OBJECT,
                properties: {
                    avoid_claims: { type: Type.ARRAY, items: { type: Type.STRING } },
                    disallowed_topics: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: ['avoid_claims', 'disallowed_topics'],
            },
            style: {
                type: Type.OBJECT,
                properties: {
                    tone: { type: Type.STRING },
                    formatting: { type: Type.STRING },
                    temperature_bias: { type: Type.NUMBER },
                },
                required: ['tone', 'formatting', 'temperature_bias'],
            },
            goals: { type: Type.ARRAY, items: { type: Type.STRING } },
            tool_prefs: {
                type: Type.OBJECT,
                properties: {
                    use_web: { type: Type.BOOLEAN },
                    use_code: { type: Type.BOOLEAN },
                    use_math: { type: Type.BOOLEAN },
                    plugins: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
                required: ['use_web', 'use_code', 'use_math', 'plugins'],
            },
            memory_file: { type: Type.STRING },
        },
        required: ['display_name', 'voice', 'knowledge_mode', 'constraints', 'style', 'goals', 'tool_prefs', 'memory_file'],
    };


    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model,
            contents: generationPrompt,
            config: {
                temperature: 0.5,
                responseMimeType: "application/json",
                responseSchema
            },
        });
        
        const jsonText = response.text.trim();
        const newPersona = JSON.parse(jsonText);
        return newPersona;

    } catch (error) {
        console.error("Error generating persona:", error);
        throw new Error("Failed to generate a new persona. The model may have returned an invalid format.");
    }
}

import React from 'react';
import { ConversationTurn, PersonaCard } from '../types';
import { UserIcon } from './ui/icons/UserIcon';

interface ChatMessageProps {
  turn: ConversationTurn;
  persona: PersonaCard | undefined;
}

const PERSONA_COLORS = [
  'text-blue-600',
  'text-green-600',
  'text-purple-600',
  'text-red-600',
  'text-yellow-700',
  'text-indigo-600',
];

const ChatMessage: React.FC<ChatMessageProps> = ({ turn, persona }) => {
  // A simple way to assign a consistent color to each persona
  const colorClass = persona ? PERSONA_COLORS[persona.id.length % PERSONA_COLORS.length] : 'text-gray-600';

  return (
    <div className="flex items-start space-x-3">
      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center border border-gray-300">
        <UserIcon className="w-5 h-5 text-gray-500" />
      </div>
      <div className="flex-grow bg-gray-100 p-3 rounded-lg border border-gray-200">
        <p className={`font-semibold ${colorClass}`}>{persona?.display_name || turn.personaName}</p>
        <div className="text-gray-800 whitespace-pre-wrap mt-1 prose prose-sm max-w-none">
          {turn.message ? (
             <p>{turn.message}</p>
          ) : (
            <span className="animate-pulse text-gray-400">...</span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatMessage;
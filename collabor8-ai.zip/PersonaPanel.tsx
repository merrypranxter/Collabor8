import React from 'react';
import { PersonaCard } from '../types';
import Button from './ui/Button';
import Card from './ui/Card';
import { PlusIcon } from './ui/icons/PlusIcon';
import { PencilIcon } from './ui/icons/PencilIcon';
import { TrashIcon } from './ui/icons/TrashIcon';

interface PersonaPanelProps {
  personas: PersonaCard[];
  onAdd: () => void;
  onEdit: (persona: PersonaCard) => void;
  onDelete: (personaId: string) => void;
  isDisabled: boolean;
}

const PersonaPanel: React.FC<PersonaPanelProps> = ({ personas, onAdd, onEdit, onDelete, isDisabled }) => {
  return (
    <fieldset disabled={isDisabled} className="h-full flex flex-col disabled:opacity-60 transition-opacity">
      <div className="p-4 flex-shrink-0">
          <Button onClick={onAdd} size="md" className="w-full">
              <PlusIcon className="w-4 h-4 mr-1.5" />
              New Persona
          </Button>
      </div>

      <div className="space-y-3 flex-grow overflow-y-auto px-4 pb-4">
        {personas.map(p => (
          <Card key={p.id} className="p-3 bg-brand-bg-start/50 hover:bg-brand-bg-start transition-colors">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="font-semibold text-brand-primary">{p.display_name}</h3>
                <p className="text-xs text-brand-text-dark mt-1 line-clamp-3">{p.voice.bio}</p>
              </div>
              <div className="flex space-x-1 flex-shrink-0 ml-2">
                 <button onClick={() => onEdit(p)} className="text-brand-text-dark hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors">
                    <PencilIcon className="w-4 h-4" />
                 </button>
                 <button onClick={() => onDelete(p.id)} className="text-brand-text-dark hover:text-red-400 p-1 rounded-full hover:bg-white/10 transition-colors">
                    <TrashIcon className="w-4 h-4" />
                 </button>
              </div>
            </div>
          </Card>
        ))}
        {personas.length === 0 && (
          <div className="text-center py-8">
            <p className="text-brand-text-dark">No personas found.</p>
            <p className="text-sm text-brand-text-dark">Click "New Persona" to create one.</p>
          </div>
        )}
      </div>
    </fieldset>
  );
};

export default PersonaPanel;
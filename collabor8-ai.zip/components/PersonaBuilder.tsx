
import React, { useState } from 'react';
import { PersonaCard } from '../types';
import Modal from './ui/Modal';
import Input from './ui/Input';
import Textarea from './ui/Textarea';
import Button from './ui/Button';
import Select from './ui/Select';

interface PersonaBuilderProps {
  persona: PersonaCard | null;
  onSave: (persona: PersonaCard) => void;
  onClose: () => void;
}

const BLANK_PERSONA: Omit<PersonaCard, 'id'> = {
  display_name: '',
  voice: { bio: '', mannerisms: '', lexicon: [] },
  knowledge_mode: { basis: 'original', sources_allowed: [], citation_style: 'none' },
  constraints: { avoid_claims: [], disallowed_topics: [] },
  style: { tone: '', formatting: 'Standard prose', temperature_bias: 0.0 },
  goals: [],
  tool_prefs: { use_web: false, use_code: false, use_math: false, plugins: [] },
  memory_file: '',
};

const PersonaBuilder: React.FC<PersonaBuilderProps> = ({ persona, onSave, onClose }) => {
  const [formData, setFormData] = useState<PersonaCard | Omit<PersonaCard, 'id'>>(persona || BLANK_PERSONA);

  const handleChange = <T,>(section: keyof PersonaCard, field: keyof T, value: any) => {
    setFormData(prev => ({
      ...prev,
      [section]: {
        ...(prev as any)[section],
        [field]: value,
      },
    }));
  };

  const handleTopLevelChange = (field: keyof PersonaCard, value: any) => {
     setFormData(prev => ({ ...prev, [field]: value }));
  };
  
  const handleSave = () => {
    // Basic validation
    if (!formData.display_name) {
        alert("Display name is required.");
        return;
    }
    onSave(formData as PersonaCard);
  };

  const renderSection = (title: string, children: React.ReactNode) => (
    <div className="bg-brand-bg/50 p-4 rounded-lg">
        <h3 className="text-lg font-semibold text-brand-primary mb-3">{title}</h3>
        <div className="space-y-3">{children}</div>
    </div>
  );

  return (
    <Modal title={persona ? 'Edit Persona' : 'Create Persona'} onClose={onClose}>
      <div className="space-y-4 max-h-[75vh] overflow-y-auto p-1 pr-4">
        {renderSection('Core Identity', <>
          <Input label="Display Name" value={formData.display_name} onChange={e => handleTopLevelChange('display_name', e.target.value)} required/>
          <Textarea label="Bio" value={formData.voice.bio} onChange={e => handleChange<PersonaCard['voice']>('voice', 'bio', e.target.value)} rows={3} placeholder="A short biography."/>
        </>)}

        {renderSection('Voice & Style', <>
          <Textarea label="Mannerisms" value={formData.voice.mannerisms} onChange={e => handleChange<PersonaCard['voice']>('voice', 'mannerisms', e.target.value)} rows={2} placeholder="Common phrases, speech patterns."/>
          <Input label="Lexicon (comma-separated)" value={formData.voice.lexicon.join(', ')} onChange={e => handleChange<PersonaCard['voice']>('voice', 'lexicon', e.target.value.split(',').map(s => s.trim()))} placeholder="Keywords, jargon"/>
          <Input label="Tone" value={formData.style.tone} onChange={e => handleChange<PersonaCard['style']>('style', 'tone', e.target.value)} placeholder="e.g., Analytical, poetic, sarcastic"/>
        </>)}

        {renderSection('Knowledge & Constraints', <>
          <Select label="Knowledge Basis" value={formData.knowledge_mode.basis} onChange={e => handleChange<PersonaCard['knowledge_mode']>('knowledge_mode', 'basis', e.target.value)}>
              <option value="original">Original</option>
              <option value="fictional">Fictional</option>
              <option value="public_figure_emulation">Public Figure Emulation</option>
          </Select>
          <Input label="Disallowed Topics (comma-separated)" value={formData.constraints.disallowed_topics.join(', ')} onChange={e => handleChange<PersonaCard['constraints']>('constraints', 'disallowed_topics', e.target.value.split(',').map(s => s.trim()))} />
        </>)}

         {renderSection('Goals', <>
            <Textarea label="Goals (one per line)" value={formData.goals.join('\n')} onChange={e => handleTopLevelChange('goals', e.target.value.split('\n'))} rows={3} placeholder="What does this persona want to achieve?"/>
         </>)}
      </div>

      <div className="mt-6 flex justify-end space-x-3">
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        <Button onClick={handleSave}>Save Persona</Button>
      </div>
    </Modal>
  );
};

export default PersonaBuilder;

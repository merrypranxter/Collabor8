import React from 'react';
import { ArenaSession, PersonaCard, DebateStyle, OutputMode, AppMode, ModeConfig } from '../types';
import Button from './ui/Button';
import Input from './ui/Input';
import Textarea from './ui/Textarea';
import Select from './ui/Select';
import { SparklesIcon } from './ui/icons/SparklesIcon';

interface SessionConfigPanelProps {
  config: ArenaSession;
  setConfig: React.Dispatch<React.SetStateAction<ArenaSession>>;
  personas: PersonaCard[];
  isLoading: boolean;
  onStart: () => void;
  debateStyles: DebateStyle[];
  outputModes: OutputMode[];
  modes: ModeConfig[];
  // FIX: Added isDisabled prop to allow disabling the panel during an active session.
  isDisabled: boolean;
}

const SessionConfigPanel: React.FC<SessionConfigPanelProps> = ({
  config,
  setConfig,
  personas,
  isLoading,
  onStart,
  debateStyles,
  outputModes,
  modes,
  isDisabled
}) => {
  const handlePersonaToggle = (personaId: string) => {
    const newPersonas = config.personas.includes(personaId)
      ? config.personas.filter(id => id !== personaId)
      : [...config.personas, personaId];
    setConfig({ ...config, personas: newPersonas });
  };

  const selectedMode = modes.find(m => m.name === config.mode);

  return (
    // FIX: Wrapped in a fieldset to easily disable all controls within.
    <fieldset disabled={isDisabled} className="h-full flex flex-col disabled:opacity-60 transition-opacity">
        <div className="p-4 space-y-4 overflow-y-auto flex-grow">
        <div>
            <label className="block text-sm font-medium text-brand-text-dark mb-1">Topic</label>
            <Input
            value={config.topic}
            onChange={e => setConfig({ ...config, topic: e.target.value })}
            placeholder="What should they talk about?"
            />
        </div>
        <div>
            <label className="block text-sm font-medium text-brand-text-dark mb-1">Instructions</label>
            <Textarea
            value={config.instructions}
            onChange={e => setConfig({ ...config, instructions: e.target.value })}
            placeholder="Specific goals, constraints, etc."
            rows={3}
            />
        </div>
        <div>
            <label className="block text-sm font-medium text-brand-text-dark mb-1">Personas</label>
            <div className="grid grid-cols-2 gap-2 mt-2">
            {personas.map(p => (
                <button
                key={p.id}
                onClick={() => handlePersonaToggle(p.id)}
                className={`text-sm px-3 py-1.5 rounded-md transition-all duration-200 border ${
                    config.personas.includes(p.id)
                    ? 'bg-brand-primary text-black font-semibold border-brand-primary'
                    : 'bg-brand-surface hover:bg-brand-bg-start border-brand-border hover:border-gray-500 text-brand-text-light'
                }`}
                >
                {p.display_name}
                </button>
            ))}
            </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
            <div>
                <label className="block text-sm font-medium text-brand-text-dark mb-1">Debate Style</label>
                <Select
                value={config.debate_style}
                onChange={e => setConfig({ ...config, debate_style: e.target.value as DebateStyle })}
                >
                {debateStyles.map(style => <option key={style} value={style}>{style}</option>)}
                </Select>
            </div>
            <div>
                <label className="block text-sm font-medium text-brand-text-dark mb-1">Output Mode</label>
                <Select
                value={config.output_mode}
                onChange={e => setConfig({ ...config, output_mode: e.target.value as OutputMode })}
                >
                {outputModes.map(mode => <option key={mode} value={mode}>{mode.replace(/_/g, ' ')}</option>)}
                </Select>
            </div>
        </div>
        <div>
            <label className="block text-sm font-medium text-brand-text-dark mb-1">Rounds</label>
            <div className="flex items-center space-x-3">
            <input
                type="range"
                min="1"
                max={selectedMode?.max_rounds || 20}
                value={config.rounds}
                onChange={e => setConfig({ ...config, rounds: parseInt(e.target.value, 10) })}
                className="w-full h-2 bg-brand-border rounded-lg appearance-none cursor-pointer accent-brand-primary"
            />
            <span className="text-white font-mono bg-brand-bg-start px-2 py-1 rounded-md text-sm w-12 text-center">{config.rounds}</span>
            </div>
        </div>
        <div>
            <label className="block text-sm font-medium text-brand-text-dark mb-2">Mode</label>
            <div className="grid grid-cols-3 gap-2">
            {modes.map(mode => (
                <button
                key={mode.name}
                onClick={() => setConfig({ ...config, mode: mode.name, rounds: Math.min(config.rounds, mode.max_rounds) })}
                className={`px-2 py-2 rounded-md text-sm font-semibold transition-all duration-200 border-2 ${
                    config.mode === mode.name
                    ? `${mode.visuals} text-white bg-white/10`
                    : 'border-transparent bg-brand-surface hover:bg-brand-bg-start text-brand-text-light'
                }`}
                >
                {mode.name}
                </button>
            ))}
            </div>
            {selectedMode?.disclaimer && <p className="text-xs text-brand-text-dark mt-2 p-2 bg-black/20 rounded-md">{selectedMode.disclaimer}</p>}
        </div>
        </div>
        <div className="p-4 mt-auto border-t border-brand-border">
            <Button onClick={onStart} disabled={isLoading || config.personas.length < 1} className="w-full">
                <SparklesIcon className="w-5 h-5 mr-2" />
                {isLoading ? 'Generating...' : 'Start Session'}
            </Button>
        </div>
    </fieldset>
  );
};

export default SessionConfigPanel;

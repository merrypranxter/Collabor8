import React from 'react';
import Modal from './ui/Modal';
import { SparklesIcon } from './ui/icons/SparklesIcon';
import { DocumentTextIcon } from './ui/icons/DocumentTextIcon';

interface PersonaCreationChoiceModalProps {
  onClose: () => void;
  onChooseManual: () => void;
  onChooseGenerate: () => void;
}

const PersonaCreationChoiceModal: React.FC<PersonaCreationChoiceModalProps> = ({
  onClose,
  onChooseManual,
  onChooseGenerate,
}) => {
  return (
    <Modal title="Create a New Persona" onClose={onClose}>
      <p className="text-brand-text-dark mb-6">How would you like to create your new persona?</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        <button 
          onClick={onChooseManual} 
          className="flex flex-col items-center justify-center p-6 bg-brand-bg/50 hover:bg-brand-bg/80 border border-brand-border rounded-lg transition-all duration-200 text-left focus:outline-none focus:ring-2 focus:ring-brand-primary"
        >
          <DocumentTextIcon className="w-10 h-10 mb-3 text-brand-primary" />
          <h3 className="font-semibold text-white">Create Manually</h3>
          <p className="text-sm text-brand-text-dark mt-1 text-center">Fill out a detailed form to define every aspect of your persona.</p>
        </button>

        <button 
          onClick={onChooseGenerate} 
          className="flex flex-col items-center justify-center p-6 bg-brand-bg/50 hover:bg-brand-bg/80 border border-brand-border rounded-lg transition-all duration-200 text-left focus:outline-none focus:ring-2 focus:ring-brand-primary"
        >
          <SparklesIcon className="w-10 h-10 mb-3 text-brand-primary" />
          <h3 className="font-semibold text-white">Generate with AI</h3>
          <p className="text-sm text-brand-text-dark mt-1 text-center">Describe the persona you want, and let AI build the profile for you.</p>
        </button>

      </div>
    </Modal>
  );
};

export default PersonaCreationChoiceModal;

import React, { useState } from 'react';
import { PersonaCard } from '../types';
import Modal from './ui/Modal';
import Textarea from './ui/Textarea';
import Button from './ui/Button';
import Spinner from './ui/Spinner';
import { generatePersonaFromPrompt } from '../services/geminiService';
import { SparklesIcon } from './ui/icons/SparklesIcon';

interface PersonaGeneratorModalProps {
  onSave: (persona: Omit<PersonaCard, 'id'>) => void;
  onClose: () => void;
}

const PersonaGeneratorModal: React.FC<PersonaGeneratorModalProps> = ({ onSave, onClose }) => {
  const [prompt, setPrompt] = useState('');
  const [generatedPersona, setGeneratedPersona] = useState<Omit<PersonaCard, 'id'> | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async () => {
    if (!prompt.trim()) return;
    setIsLoading(true);
    setError(null);
    setGeneratedPersona(null);
    try {
      const personaData = await generatePersonaFromPrompt(prompt);
      setGeneratedPersona(personaData);
    } catch (e: any) {
      setError(e.message || 'An unknown error occurred.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = () => {
    if (generatedPersona) {
      onSave(generatedPersona);
    }
  };
  
  const handleTryAgain = () => {
    setGeneratedPersona(null);
    setError(null);
  }

  return (
    <Modal title="Generate Persona with AI" onClose={onClose}>
      <div className="space-y-4">
        {!generatedPersona && (
          <>
            <Textarea
              label="Describe the persona you want to create"
              value={prompt}
              onChange={e => setPrompt(e.target.value)}
              placeholder="e.g., A cynical noir detective from the 1940s who has seen it all, but still has a soft spot for the truth."
              rows={4}
              disabled={isLoading}
            />
            <Button onClick={handleGenerate} disabled={isLoading || !prompt.trim()} className="w-full">
              {isLoading ? <Spinner /> : <SparklesIcon className="w-5 h-5 mr-2" />}
              {isLoading ? 'Generating...' : 'Generate Persona'}
            </Button>
            {error && <p className="text-sm text-red-400 bg-red-900/50 p-2 rounded-md">{error}</p>}
          </>
        )}

        {generatedPersona && !isLoading && (
            <div className="space-y-4 p-4 bg-brand-bg/50 rounded-lg max-h-[50vh] overflow-y-auto">
                <h3 className="text-xl font-bold text-brand-primary">{generatedPersona.display_name}</h3>
                <p className="text-sm text-brand-text-light"><span className="font-semibold text-brand-text-dark">Bio: </span>{generatedPersona.voice.bio}</p>
                <p className="text-sm text-brand-text-light"><span className="font-semibold text-brand-text-dark">Tone: </span>{generatedPersona.style.tone}</p>
                <p className="text-sm text-brand-text-light"><span className="font-semibold text-brand-text-dark">Goals: </span>{generatedPersona.goals.join(', ')}</p>
            </div>
        )}
      </div>

      <div className="mt-6 flex justify-end space-x-3">
        <Button variant="secondary" onClick={onClose}>Cancel</Button>
        {generatedPersona && (
            <>
            <Button variant="secondary" onClick={handleTryAgain}>Try Again</Button>
            <Button onClick={handleSave}>Save Persona</Button>
            </>
        )}
      </div>
    </Modal>
  );
};

export default PersonaGeneratorModal;

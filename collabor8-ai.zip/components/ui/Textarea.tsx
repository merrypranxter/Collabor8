
import React from 'react';

interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
    label?: string;
}

const Textarea: React.FC<TextareaProps> = ({ label, id, className = '', ...props }) => {
  const textareaId = id || (label ? label.replace(/\s+/g, '-').toLowerCase() : undefined);
  
  return (
    <div>
      {label && <label htmlFor={textareaId} className="block text-sm font-medium text-brand-text-dark mb-1">{label}</label>}
      <textarea
        id={textareaId}
        className={`w-full bg-brand-surface border border-brand-border rounded-md px-3 py-2 text-brand-text-light placeholder-brand-text-dark focus:ring-brand-secondary focus:border-brand-secondary transition-colors duration-200 ${className}`}
        {...props}
      />
    </div>
  );
};

export default Textarea;
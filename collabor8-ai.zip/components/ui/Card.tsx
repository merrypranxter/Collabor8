
import React from 'react';

interface CardProps {
  children: React.ReactNode;
  className?: string;
}

const Card: React.FC<CardProps> = ({ children, className = '' }) => {
  return (
    <div className={`bg-brand-surface border border-brand-border rounded-lg shadow-glow ${className}`}>
      {children}
    </div>
  );
};

export default Card;
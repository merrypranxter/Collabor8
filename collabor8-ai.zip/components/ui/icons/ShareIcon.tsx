import React from 'react';
export const ShareIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.195.025.39.042.583.05a2.25 2.25 0 011.942 2.086c0 .35-.07.686-.2.983m0-2.086a2.25 2.25 0 00-1.942-2.086M14.25 7.5a2.25 2.25 0 100 4.5 2.25 2.25 0 000-4.5zm0 4.5c.195.025.39.042.583.05a2.25 2.25 0 011.942 2.086c0 .35-.07.686-.2.983m0-2.086a2.25 2.25 0 00-1.942-2.086M7.217 10.907a2.25 2.25 0 112.186 0m-2.186 0A2.25 2.25 0 005.25 12a2.25 2.25 0 00-2.25 2.25m13.5-4.5a2.25 2.25 0 112.186 0m-2.186 0a2.25 2.25 0 002.25 2.25" />
    </svg>
);

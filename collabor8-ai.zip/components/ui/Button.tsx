import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary';
  size?: 'sm' | 'md' | 'lg';
}

const Button: React.FC<ButtonProps> = ({
  children,
  className = '',
  variant = 'primary',
  size = 'md',
  ...props
}) => {
  const baseStyles = 'inline-flex items-center justify-center font-semibold rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed tracking-wide';

  const variantStyles = {
    primary: 'bg-brand-primary hover:bg-brand-primary-hover text-black focus:ring-brand-primary focus:ring-offset-brand-surface',
    secondary: 'bg-gray-100 hover:bg-gray-200 border border-gray-300 text-gray-700 focus:ring-indigo-500 focus:ring-offset-white',
  };
  
  // Special case for dark theme secondary button
  const darkThemeSecondary = 'dark:bg-brand-surface dark:hover:bg-brand-bg-start dark:border-brand-border dark:text-brand-text-light dark:focus:ring-brand-border dark:focus:ring-offset-brand-surface'


  const sizeStyles = {
    sm: 'px-3 py-1.5 text-xs',
    md: 'px-4 py-2 text-sm',
    lg: 'px-6 py-3 text-base',
  };

  return (
    <button
      className={`${baseStyles} ${variant === 'primary' ? variantStyles.primary : `${variantStyles.secondary} ${darkThemeSecondary}`} ${sizeStyles[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};

export default Button;
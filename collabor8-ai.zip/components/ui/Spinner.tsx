
import React from 'react';

const Spinner: React.FC = () => {
  return (
    <div className="w-6 h-6 border-2 border-brand-text-dark border-t-brand-primary rounded-full animate-spin"></div>
  );
};

export default Spinner;

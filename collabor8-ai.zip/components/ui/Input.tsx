
import React from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
}

const Input: React.FC<InputProps> = ({ label, id, className = '', ...props }) => {
  const inputId = id || (label ? label.replace(/\s+/g, '-').toLowerCase() : undefined);
  
  return (
    <div>
      {label && <label htmlFor={inputId} className="block text-sm font-medium text-brand-text-dark mb-1">{label}{props.required && <span className="text-red-400 ml-1">*</span>}</label>}
      <input
        id={inputId}
        className={`w-full bg-brand-surface border border-brand-border rounded-md px-3 py-2 text-brand-text-light placeholder-brand-text-dark focus:ring-brand-secondary focus:border-brand-secondary transition-colors duration-200 ${className}`}
        {...props}
      />
    </div>
  );
};

export default Input;
/**
 * @file ConversationPanel.tsx
 * This component displays the main conversation/debate area when a session is active.
 * It renders the sequence of messages from different personas, shows the session topic,
 * and includes controls for ending the session or returning to the configuration screen.
 * It also handles auto-scrolling to the latest message.
 */
import React, { useEffect, useRef, useState } from 'react';
import { jsPDF } from 'jspdf';
import { ArenaSession, ConversationTurn, PersonaCard } from '../types';
import ChatMessage from './ChatMessage';
import Spinner from './ui/Spinner';
import Button from './ui/Button';
// FIX: Corrected import paths for icons and added missing SparklesIcon import.
import { ShareIcon } from './ui/icons/ShareIcon';
import { CopyIcon } from './ui/icons/CopyIcon';
import { DownloadIcon } from './ui/icons/DownloadIcon';
import { SparklesIcon } from './ui/icons/SparklesIcon';

interface ConversationPanelProps {
  session: ArenaSession;
  conversation: ConversationTurn[];
  personas: PersonaCard[];
  isLoading: boolean;
  error: string | null;
  isSessionActive: boolean;
  onEndSession: () => void;
  onReturnToConfig: () => void;
}

const ConversationPanel: React.FC<ConversationPanelProps> = ({
  session,
  conversation,
  personas,
  isLoading,
  error,
  isSessionActive,
  onEndSession,
  onReturnToConfig
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [isExportMenuOpen, setIsExportMenuOpen] = useState(false);
  const [copyStatus, setCopyStatus] = useState('Copy');

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [conversation, isLoading]);

  const getPersonaById = (id: string) => personas.find(p => p.id === id);

  const formatTranscript = () => {
    let text = `Topic: ${session.topic}\n\n`;
    text += conversation.map(turn => `${turn.personaName}:\n${turn.message}`).join('\n\n---\n\n');
    return text;
  };

  const handleCopyToClipboard = () => {
    navigator.clipboard.writeText(formatTranscript()).then(() => {
      setCopyStatus('Copied!');
      setTimeout(() => setCopyStatus('Copy'), 2000);
    });
  };

  const handleDownloadTxt = () => {
    const blob = new Blob([formatTranscript()], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `collabor8-session-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleDownloadPdf = () => {
    const doc = new jsPDF();
    doc.setFont('Helvetica');
    doc.setFontSize(16);
    doc.text(`Topic: ${session.topic}`, 10, 10);
    doc.setFontSize(11);
    const transcript = conversation.map(turn => `${turn.personaName}:\n${turn.message}`);
    const splitText = doc.splitTextToSize(transcript.join('\n\n---\n\n'), 180);
    doc.text(splitText, 10, 20);
    doc.save(`collabor8-session-${Date.now()}.pdf`);
  };

  if (!isSessionActive) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center p-8 bg-brand-surface border border-brand-border rounded-lg">
          <SparklesIcon className="w-16 h-16 text-brand-border" />
          <h2 className="mt-4 text-2xl font-bold text-white">Session Standby</h2>
          <p className="mt-2 text-brand-text-dark">Configure your session and personas in the side panel and click "Start Session" to begin.</p>
      </div>
    );
  }

  return (
    <div className="h-full p-0.5 rounded-lg bg-gradient-to-br from-gray-400 to-gray-600">
      <div className="bg-white rounded-md h-full flex flex-col text-gray-900">
        {/* Header */}
        <div className="flex-shrink-0 p-4 border-b border-gray-200 flex justify-between items-center">
          <div>
            <h3 className="text-lg font-bold text-gray-900">{session.topic}</h3>
            <p className="text-sm text-gray-500 mt-1 line-clamp-1">{session.instructions}</p>
          </div>
          <div className="flex items-center space-x-2">
            {isLoading ? (
              <Button variant="secondary" size="sm" onClick={onEndSession}>Stop Session</Button>
            ) : (
              <Button variant="secondary" size="sm" onClick={onReturnToConfig}>Back to Config</Button>
            )}
            <div className="relative">
              <button
                onClick={() => setIsExportMenuOpen(!isExportMenuOpen)}
                className="p-2 rounded-md hover:bg-gray-100 text-gray-500 hover:text-gray-800 transition-colors"
                aria-label="Export conversation"
              >
                <ShareIcon className="w-5 h-5" />
              </button>
              {isExportMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg border border-gray-200 z-10">
                  <button onClick={handleCopyToClipboard} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center space-x-2">
                    <CopyIcon className="w-4 h-4" /> <span>{copyStatus}</span>
                  </button>
                  <button onClick={handleDownloadTxt} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center space-x-2">
                    <DownloadIcon className="w-4 h-4" /> <span>Download .txt</span>
                  </button>
                  <button onClick={handleDownloadPdf} className="w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-gray-100 flex items-center space-x-2">
                     <DownloadIcon className="w-4 h-4" /> <span>Download .pdf</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Conversation Body */}
        <div ref={scrollRef} className="flex-grow overflow-y-auto p-4 space-y-4">
          {conversation.map((turn, index) => (
            <ChatMessage key={index} turn={turn} persona={getPersonaById(turn.personaId)} />
          ))}
          {isLoading && (
            <div className="flex items-center space-x-3 p-4">
              <Spinner />
              <p className="text-gray-500 italic">Awaiting next response...</p>
            </div>
          )}
          {error && (
            <div className="p-4 bg-red-50 text-red-700 rounded-lg">
              <p className="font-semibold">An Error Occurred</p>
              <p className="text-sm">{error}</p>
            </div>
          )}
          {!isLoading && !error && conversation.length > 0 && (
            <div className="text-center text-sm text-gray-400 pt-4">-- End of Session --</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ConversationPanel;
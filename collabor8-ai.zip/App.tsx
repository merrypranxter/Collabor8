import React, { useState, useCallback } from 'react';
import { ArenaSession, PersonaCard, ConversationTurn } from './types';
import { INITIAL_PERSONAS, DEBATE_STYLES, OUTPUT_MODES, MODES } from './constants';
import { generateDebateTurnStream } from './services/geminiService';

import PersonaPanel from './components/PersonaPanel';
import SessionConfigPanel from './components/SessionConfigPanel';
import ConversationPanel from './components/ConversationPanel';
import PersonaBuilder from './components/PersonaBuilder';
import PersonaCreationChoiceModal from './components/PersonaCreationChoiceModal';
import PersonaGeneratorModal from './components/PersonaGeneratorModal';
import { SparklesIcon } from './components/ui/icons/SparklesIcon';

type ActiveTab = 'config' | 'personas';

const App: React.FC = () => {
    // State for personas, including user-created ones
    const [personas, setPersonas] = useState<PersonaCard[]>(INITIAL_PERSONAS);
    
    // State for the session configuration form
    const [sessionConfig, setSessionConfig] = useState<ArenaSession>({
        topic: 'Should humanity prioritize colonizing Mars or solving Earth\'s problems?',
        instructions: 'Focus on the ethical, economic, and technological implications. Each persona should argue from their core principles.',
        personas: [INITIAL_PERSONAS[0].id, INITIAL_PERSONAS[2].id],
        debate_style: 'Socratic Drill',
        rounds: 4,
        output_mode: 'consensus_report',
        mode: 'Normal',
    });

    // State for the live conversation
    const [conversation, setConversation] = useState<ConversationTurn[]>([]);
    const [currentTurn, setCurrentTurn] = useState<ConversationTurn | null>(null);
    
    // Application view state ('configuring', 'running', 'finished')
    const [appState, setAppState] = useState<'configuring' | 'running' | 'finished'>('configuring');
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [stopSignal, setStopSignal] = useState(false);

    // State to manage which modal is open
    const [modalState, setModalState] = useState<'closed' | 'choice' | 'manual' | 'generate'>('closed');
    const [editingPersona, setEditingPersona] = useState<PersonaCard | null>(null);
    const [activeTab, setActiveTab] = useState<ActiveTab>('config');

    // Derived state to get the config for the current mode (Normal, Unhinged, etc.)
    const currentModeConfig = MODES.find(m => m.name === sessionConfig.mode);

    const runSession = useCallback(async () => {
        if (sessionConfig.personas.length < 1) {
            setError("Please select at least one persona to start the session.");
            return;
        }

        setAppState('running');
        setIsLoading(true);
        setError(null);
        setConversation([]);
        setStopSignal(false);

        let tempConversation: ConversationTurn[] = [];

        for (let i = 0; i < sessionConfig.rounds * sessionConfig.personas.length; i++) {
            if (stopSignal) {
                console.log("Session stopped by user.");
                break;
            }

            const personaId = sessionConfig.personas[i % sessionConfig.personas.length];
            const persona = personas.find(p => p.id === personaId);

            if (!persona) continue;
            
            const currentPersonaTurn: ConversationTurn = {
                personaId: persona.id,
                personaName: persona.display_name,
                message: '',
            };
            setCurrentTurn(currentPersonaTurn);

            try {
                const stream = generateDebateTurnStream(
                    sessionConfig,
                    persona,
                    personas.filter(p => sessionConfig.personas.includes(p.id)),
                    tempConversation,
                    currentModeConfig
                );
                
                let fullMessage = '';
                for await (const chunk of stream) {
                    if (stopSignal) break;
                    fullMessage += chunk;
                    setCurrentTurn({ ...currentPersonaTurn, message: fullMessage });
                }

                if (stopSignal) break;

                const finalTurn = { ...currentPersonaTurn, message: fullMessage };
                tempConversation = [...tempConversation, finalTurn];
                setConversation(tempConversation);

            } catch (err: any) {
                setError(err.message || "An error occurred during the debate.");
                break;
            } finally {
                setCurrentTurn(null);
            }
        }

        setIsLoading(false);
        setAppState('finished');

    }, [sessionConfig, personas, currentModeConfig, stopSignal]);


    // Event Handlers
    const handleStartSession = () => {
        runSession();
    };

    const handleEndSession = () => {
        setStopSignal(true);
        setIsLoading(false);
        setAppState('finished');
        setCurrentTurn(null);
    };

    const handleReturnToConfig = () => {
        setConversation([]);
        setError(null);
        setAppState('configuring');
    };

    // Persona CRUD Handlers
    const handleAddPersona = () => {
        setEditingPersona(null);
        setModalState('choice');
    };
    
    const handleEditPersona = (persona: PersonaCard) => {
        setEditingPersona(persona);
        setModalState('manual');
    };

    const handleDeletePersona = (personaId: string) => {
        if (window.confirm("Are you sure you want to delete this persona?")) {
            setPersonas(personas.filter(p => p.id !== personaId));
            setSessionConfig(prev => ({
                ...prev,
                personas: prev.personas.filter(id => id !== personaId)
            }));
        }
    };

    const handleSavePersona = (personaData: PersonaCard | Omit<PersonaCard, 'id'>) => {
        if ('id' in personaData && personaData.id) {
            setPersonas(personas.map(p => p.id === personaData.id ? personaData : p));
        } else {
            const newPersona: PersonaCard = {
                ...personaData,
                id: `${personaData.display_name.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}`
            };
            setPersonas([...personas, newPersona]);
        }
        setModalState('closed');
        setEditingPersona(null);
    };

    const isSessionActive = appState !== 'configuring';

    const TabButton: React.FC<{tabName: ActiveTab, currentTab: ActiveTab, onClick: () => void, children: React.ReactNode}> = ({ tabName, currentTab, onClick, children }) => (
        <button
            onClick={onClick}
            className={`px-4 py-3 font-semibold text-sm transition-colors w-1/2 ${
                currentTab === tabName
                ? 'text-white border-b-2 border-brand-primary bg-white/5'
                : 'text-brand-text-dark hover:bg-white/5 hover:text-white'
            }`}
        >
            {children}
        </button>
    );

    return (
        <div className="bg-gradient-to-b from-brand-bg-start to-brand-bg min-h-screen font-sans text-brand-text-light flex flex-col">
            <header className="flex items-center justify-center p-4 border-b border-brand-border flex-shrink-0 bg-brand-surface shadow-lg">
                <div className="flex items-center space-x-3">
                    <SparklesIcon className="w-8 h-8 text-brand-primary" />
                    <h1 className="text-3xl font-bold text-white tracking-wider">Collabor8 AI</h1>
                </div>
            </header>

            <main className="flex-grow grid grid-cols-1 lg:grid-cols-12 gap-4 p-4 overflow-hidden">
                {/* Left Panel: Main Content (Conversation) */}
                <div className="lg:col-span-7 overflow-hidden flex flex-col">
                   <ConversationPanel
                        session={sessionConfig}
                        conversation={currentTurn ? [...conversation, currentTurn] : conversation}
                        personas={personas}
                        isLoading={isLoading}
                        error={error}
                        isSessionActive={isSessionActive}
                        onEndSession={handleEndSession}
                        onReturnToConfig={handleReturnToConfig}
                    />
                </div>

                {/* Right Panel: Tabbed Config and Personas */}
                <div className="lg:col-span-5 bg-brand-surface border border-brand-border rounded-lg overflow-hidden flex flex-col">
                    <div className="flex border-b border-brand-border flex-shrink-0">
                        <TabButton tabName="config" currentTab={activeTab} onClick={() => setActiveTab('config')}>
                            Session Config
                        </TabButton>
                        <TabButton tabName="personas" currentTab={activeTab} onClick={() => setActiveTab('personas')}>
                            Personas
                        </TabButton>
                    </div>
                    <div className="flex-grow overflow-hidden">
                        {activeTab === 'config' && (
                            <SessionConfigPanel
                                config={sessionConfig}
                                setConfig={setSessionConfig}
                                personas={personas}
                                isLoading={isLoading}
                                onStart={handleStartSession}
                                debateStyles={DEBATE_STYLES}
                                outputModes={OUTPUT_MODES}
                                modes={MODES}
                                isDisabled={isSessionActive}
                            />
                        )}
                        {activeTab === 'personas' && (
                            <PersonaPanel
                                personas={personas}
                                onAdd={handleAddPersona}
                                onEdit={handleEditPersona}
                                onDelete={handleDeletePersona}
                                isDisabled={isSessionActive}
                            />
                        )}
                    </div>
                </div>
            </main>

            {/* Modals for Persona Creation/Editing */}
            {modalState === 'choice' && (
                <PersonaCreationChoiceModal
                    onClose={() => setModalState('closed')}
                    onChooseManual={() => setModalState('manual')}
                    onChooseGenerate={() => setModalState('generate')}
                />
            )}

            {modalState === 'manual' && (
                <PersonaBuilder
                    persona={editingPersona}
                    onSave={handleSavePersona}
                    onClose={() => { setModalState('closed'); setEditingPersona(null); }}
                />
            )}
            
            {modalState === 'generate' && (
                <PersonaGeneratorModal
                    onSave={handleSavePersona}
                    onClose={() => setModalState('closed')}
                />
            )}
        </div>
    );
};

export default App;
